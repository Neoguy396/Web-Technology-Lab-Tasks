<?php



$arr=array("Samreen"=>"31","Jahan"=>"41","Warisha"=>"39","Rania"=>"40") ;



echo "sort associative arrays in ascending order, according to the value <br>";
asort($arr); 


foreach ($arr as  $value) {
	echo "$value <br>";
}

echo "<hr>";

echo "sort associative arrays in ascending order, according to the key <br>";

ksort($arr) ;  //- sort associative arrays in ascending order, according to the key


foreach ($arr as  $value) {
	echo "$value <br>";
}

echo "<hr>";

echo "sort associative arrays in descending order, according to the value <br>";
arsort($arr);  //- sort associative arrays in descending order, according to the value

foreach ($arr as  $value) {
	echo "$value <br>";
}

echo "<hr>";

echo "sort associative arrays in descending order, according to the key <br>";
krsort($arr) ; //- sort associative arrays in descending order, according to the key
foreach ($arr as  $value) {
	echo "$value <br>";
}


?>