<?php

$myarray = array(5,3,3,2,4,1);
$sortedarray = array_unique($myarray);

for($x=0;$x<sizeof($myarray);$x++){ 

echo $sortedarray[$x];
}



?>