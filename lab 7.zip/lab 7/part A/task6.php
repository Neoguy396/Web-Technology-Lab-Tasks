<?php
// $x=1;
// echo "";




?>




<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table cellspacing=40px>
<tr>
<th>1</th>	
<th>2</th>
<th>3</th>
<th>4</th>
<th>5</th>
<th>6</th>
<th>7</th>
</tr>
      <?php 
      $y=2;
     while($y<8){
        for($x=1;$x<8;$x++){
        echo "<th>",$y*$x,"</th>";
        }
        echo "<br>";
        $y++;
     }
	?>
</tr>
</table>
</body>
</html>