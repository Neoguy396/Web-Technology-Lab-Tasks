<?php

$var = "A00";

$x=1;

while($x<6){

     echo substr($var, 0,-1).$x,"<br>";
     $x++;
}




?>