<?php

 $x = 999996;
    $var = $x . "";

    $sum = 0;
    for ($i = 0; $i < strlen($var); ++$i)
    {
        $sum += $var[$i];
    }
    
    if($sum==23):
    echo "Its your lucky day";
    endif;



?>