<?php
$lines=file("test.txt");
echo "Lines: ".count($lines)."<br>";
$text=implode($lines);
echo "Num of Words: ".str_word_count($text)."<br>";
echo $text;
?>