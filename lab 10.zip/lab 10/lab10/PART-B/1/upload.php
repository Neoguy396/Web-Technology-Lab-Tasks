<?php
$target_folder = "C:/wamp64/www/Labs/lab10/taskbi/Upload/";
$trgt_file = $target_folder . basename($_FILES["uploadedFile"]["name"]);
$uploaded = 1;
$imageFileType = strtolower(pathinfo($trgt_file,PATHINFO_EXTENSION));
if(isset($_POST["submit"])) {

   
}
if (file_exists($trgt_file)) {
    echo "Sorry, file already exists.";
    $uploaded = 0;
}
if ($_FILES["uploadedFile"]["size"] > 2000000) {
    echo "Sorry, file size is greater than 2MB";
    $uploaded = 0;
}
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "pdf" ) {
    echo "Only JPG PNG and PDF files are allowed to upload";
    $uploaded = 0;
}
if ($uploaded == 0) {
    echo "File is not uploaded.";

} else {
    if (move_uploaded_file($_FILES["uploadedFile"]["tmp_name"], $trgt_file)) {
            	$fileName=basename( $_FILES["uploadedFile"]["name"]);
        echo "<H2>The file ". basename( $_FILES["uploadedFile"]["name"]). " has been uploaded</H2>";
    } else {
        echo "Error in uploading your file";
    }
}
?>
