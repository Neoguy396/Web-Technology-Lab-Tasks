<?php 

rename("folder","newFolder");
echo "Succesfully renamed folder to newFolder";


 ?>