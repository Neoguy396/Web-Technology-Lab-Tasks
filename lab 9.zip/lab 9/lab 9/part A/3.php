<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>

$(document).ready(function(){
  $("#fname").focus(function(){
    $("#span1").css("display", "block").fadeTo("slow", 0.15);
  });

  $("#Mname").focus(function(){
    $("#span2").css("display", "block").fadeTo("slow", 0.15);
  });
  $("#Lname").focus(function(){
    $("#span3").css("display", "block").fadeTo("slow", 0.15);
  });
});
</script>
<style type="text/css">
	#span1 {
background: yellow;
color: white;
}
	#span2 {
background: green;
color: white;
}
	#span3 {
background: orange;
color: white;
}
span{
	display: none; 	
}
</style>
</head>
<body>

Enter FirstName:- <input type="text" name="Fname" placeholder="enter First name" id = "fname">
<br><br>	
Enter MiddleName:- <input type="text" name="Mname" placeholder="enter Middle name" id = "Mname">
<br><br>	
Enter LastName:- <input type="text" name="Lname" placeholder="enter Last name" id = "Lname">
<br><br>
<div>
	
<span id = "span1"> Enter First Name </span>
<span id = "span2"> Enter Middle Name </span>
<span id = "span3"> Enter Last Name </span>
</div>
</body>
</html>