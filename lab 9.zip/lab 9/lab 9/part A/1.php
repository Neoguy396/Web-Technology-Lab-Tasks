<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("h1,h2,h3" ).click(function() {
  $( this ).slideUp();
});
  });
</script>
</head>
<body>
	
<h1>Heading-1</h1>
<h2>Heading-2</h2>
<h3>Heading-3</h3>
</body>
</html>