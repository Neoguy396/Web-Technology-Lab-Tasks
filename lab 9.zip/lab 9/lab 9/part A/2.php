<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
 var pdbl = $( "p:first" );
pdbl.dblclick(function() {
  pdbl.toggleClass( "dbl" );
});
  });
</script>

<style type="text/css">
	p {
background: blue;
color: white;
}
p.dbl {
background: yellow;
color: black;>
}



</style>
</head>
<body>
	
<p>Double click to change the color!</p>
</body>
</html>