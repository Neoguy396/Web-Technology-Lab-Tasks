<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $('#Button').on("click",function() {
         $("#ul").css("display","block");
    });
  });
</script>
<style type="text/css">
	
	#ul{
		display: none;
	}
</style>
</head>
<body>
	<Button name="Button" id="Button"> Click on me to see the list! </Button><br><br>
<div id = "ul">
<ul >
	<li>16SW23</li>
	<li>16SW37</li>
	<li>16SW157</li>
	<li>16SW177</li>
	<li>16SW179</li>
</ul>
</div>
</body>
</html>