<?php
if(isset($_POST["country"])){
    // Capture selected country
    $country = $_POST["country"];
     
    // Define country and city array
    $countryArr = array(
                    "Pakistan" => array("Karachi", "Jamsabad", "Umerkot","Hyderabad","Kunri"),
                    "India" => array("lacknow", "Delhi", "Kolkatta","Bombay")
    
                   
                );
     
    // Display city dropdown based on country name
    if($country !== 'Select'){
        echo "<br><br>";
        echo " <h3>Cities:</h3>";
        echo "<select>";
        foreach($countryArr[$country] as $value){
            echo "<option>". $value . "</option>";
        }
        echo "</select>";
    } 
}
?>