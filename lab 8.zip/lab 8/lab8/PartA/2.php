<?php

if (isset($_GET['sbt'])){

	$number=$_GET['number'];
	$exponent=$_GET['exponent'];

	powerFunction($number,$exponent);
}


function powerFunction($num,$exp)
{
	# code...
	$var=1;
	for ($i=1; $i<=$exp; $i++){
		$var*=$num;
	}

	echo "<h1>ANSWER: $var</h1>";
}








?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<form method="Get">
		Number<input type="number" name="number">
		Exponent<input type="number" name="exponent">
		<input type="submit" name="sbt">
	</form>

</body>
</html>