


var children = [1, 2, 3, 4,5];
var partner =["Lala", "Nizamani", "Brad Pitt", "Zac Efron", "Amir Liquat", "Your crush"];
var loc = ["Pakistan", "USA", "UK", "Australia", "New Zealand", "Africa", "Jamaica", "Singapore"];
var job = ["Software Engineer", "CEO", "Janitor", "Rapper", "Mobster", "Footballer"];


function tellFortune(a = children[Math.floor(Math.random() * children.length)], b= partner[Math.floor(Math.random() * partner.length)], c=loc[Math.floor(Math.random() * loc.length)], d=job[Math.floor(Math.random() * job.length)] ){

document.getElementById("children").innerHTML = a;
document.getElementById("partner").innerHTML = b;
document.getElementById("loc").innerHTML = c;
document.getElementById("job").innerHTML = d;





}

