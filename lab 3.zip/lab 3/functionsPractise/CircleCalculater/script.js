


var pi = 3.1415926535898;

function calcArea(){
    var radius = document.getElementById("radius").value;
    radius = Math.pow(radius, 2)
    var a = pi * radius;

    document.getElementById("answer").innerHTML = a +"m^2";

}

function calcCircumference(){
    var radius = document.getElementById("radius").value;
    var a = 2*pi*radius;
    document.getElementById("answer").innerHTML = a +"m";

}

