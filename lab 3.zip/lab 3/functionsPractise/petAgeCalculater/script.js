var humanAge = document.getElementById('age').value;


function convert(a=humanAge){

b= a+7;
document.getElementById('textBox').innerHTML = "Your pet's age in dog/cat year is " + b;

}

