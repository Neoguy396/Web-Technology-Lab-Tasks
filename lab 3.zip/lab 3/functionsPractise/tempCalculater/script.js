function celToFah(){

	var cel = document.getElementById("celcius").value;
	var answer = cel * 1.8 + 32;

	document.getElementById("fah").value = answer;

}


function FahToCel(){

	var fah = document.getElementById("fah").value;
	var answer = fah - 32 * 0.5556;

	document.getElementById("celcius").value = answer;



}