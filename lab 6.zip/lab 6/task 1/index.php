<!DOCTYPE html>
<html>
<head>
	<title>Test for PHP</title>
</head>
<body>

<?php

phpinfo(); // info about php version is given here.

echo 'Current script owner: ' . get_current_user()."\n"; // name of the owner of the current PHP script

// swapping 2 variable and printing their value before and after swapping.

$a = 5;
$b = 10;
$c = 0; // temp var.

echo "Value of a before swapping is: ".$a." and value of b before swapping is ".$b;

$c = $b;
$b = $a;
$a = $c;



echo "\nValue of a after swapping is: ".$a." and value of b after swapping is ".$b;









?>


</body>
</html>