<?php

$var = "PHP lab: No: 06";

echo "<!DOCTYPE html>
<html>
<head>
	<title>$var</title>
</head>
<body>
<h3>$var</h3>
<br><a>$var</a>
</body>
</html>";


?>
