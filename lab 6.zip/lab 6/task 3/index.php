<!DOCTYPE html>
<html>
<head>
	<title>Test for PHP</title>
</head>
<body>

<?php

echo "Tomorrow I’ll learn something new.";
echo '<br>This is a bad command: del c:\*.*\$.<br><br>';


// Task: To test whether a number is greater than 30, 20 or 10 using ternary operator and print the result.

function trinary_Test($n){
$r = $n > 30
? "greater than 30"
: ($n > 20
? "greater than 20"
: ($n >10
? "greater than 10"
: "Input a number atleast greater than 10!")); 
echo $n." : ".$r."\n";
}
trinary_Test(32);
trinary_Test(21);
trinary_Test(12);
trinary_Test(4);


echo '<br><br>';

$url = 'http://sw.muet.edu.pk/faculty/cvs/sample.pdf';
print_r(parse_url($url));
echo parse_url($url, PHP_URL_PATH);

?>


</body>
</html>