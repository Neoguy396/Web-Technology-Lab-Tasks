<!DOCTYPE html>
<html>
<head>
	<title>Test for PHP</title>
</head>
<body>

<?php

// redirecting

header("Location: http://sw.muet.edu.pk");
?>


</body>
</html>