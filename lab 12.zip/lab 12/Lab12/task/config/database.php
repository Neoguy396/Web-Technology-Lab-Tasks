<?php
$host = "localhost";
$db_name = "my_database";
$username = "root";
$password = ""; // default is no pw.

    $con = mysqli_connect($host,$username,$password,$db_name);
    or
    die("Error!")
  

?>