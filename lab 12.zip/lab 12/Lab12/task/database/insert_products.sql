INSERT INTO `products` (`id`, `name`, `description`, `price`, `created`, `modified`) VALUES
(1, 'Call of Duty MW2', 'Best selling FPS Shooter.', 80.99, '2019-02-20 12:04:03', '2019-02-20 06:59:18'),
(3, 'Assassins Creed All Parts', 'Full series of the famous seller Assassins creed.', 299.99, '2019-02-20 12:14:29', '2019-02-20 06:59:18'),
(4, 'PUBG', 'Battle royale game.', 30, '2019-02-20 12:15:04', '2019-02-20 06:59:18'),
(5, 'Resident evil 2', 'Kill zombies.', 59.99, '2019-02-20 12:16:08', '2019-02-20 06:59:18'),
